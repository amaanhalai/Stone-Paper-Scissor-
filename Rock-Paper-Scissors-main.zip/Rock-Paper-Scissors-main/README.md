RPS (Rock Paper Scissors) with hand tracking

- Run the asset generator once to create placeholder images:
  python generate_assets.py

- Install dependencies (recommended in a virtualenv):
  pip install -r requirements.txt

- Run the game:
  python Run.py

Notes:
- The game uses your webcam and MediaPipe for hand detection.
- Press 'q' to quit the game window.
- If MediaPipe install fails on your system, let me know and I can provide an alternative lighter detector stub (less accurate).

Author and Copyright
---------------------
This project is authored by tubakhxn (GitHub username: `tubakhxn`).

License
-------
The project is provided under the MIT License. See `LICENSE` for details.

Forking, cloning and running (PowerShell)
--------------------------------------
1. Fork this repository on GitHub by clicking the "Fork" button on the repo page.
2. Clone your fork to your machine (replace <your-username> with your GitHub username):

```powershell
git clone https://github.com/tubakhxn/<repository-name>.git
cd <repository-name>
```

3. (Optional but recommended) Create and activate a virtual environment:

```powershell
python -m venv .venv
& .\.venv\Scripts\Activate.ps1
```

4. Install dependencies:

```powershell
& "C:/Users/Tuba Khan/AppData/Local/Microsoft/WindowsApps/python3.11.exe" -m pip install -r requirements.txt
```

5. Generate placeholder images (only if `images/` is empty):

```powershell
& "C:/Users/Tuba Khan/AppData/Local/Microsoft/WindowsApps/python3.11.exe" generate_assets.py
```

6. Run the game:

```powershell
& "C:/Users/Tuba Khan/AppData/Local/Microsoft/WindowsApps/python3.11.exe" Run.py
```

Notes: If your camera isn't detected, try changing the camera index in `Run.py` (cv2.VideoCapture(0) → cv2.VideoCapture(1)). If you want me to create a GitHub repo for you and push these files, I can provide the commands to run locally and what to paste in GitHub.